JLP_BlogProject
A simple Django blog application where users can create and view blog posts.

Project Setup

Prerequisites
Before running the project, ensure you have the following installed:

Python 3.x
Django 5.1.1
A virtual environment (recommended)
Installation Instructions
Follow these steps to set up and run the project:

cd yourdirecory/JLP_BlogProject

python -m venv myenv
myenv\Scripts\activate

pip install django

python manage.py makemigrations
python manage.py migrate

python manage.py runserver

http://127.0.0.1:8000/blog/
